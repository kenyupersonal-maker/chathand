# ChatHand Mac Site 模板步骤

此模板只包含私有 Site 的 B 通道源码、D1 迁移与受控宿主页面。它不含 Site、owner、密钥、服务访问凭据或发布记录。先核对 ChatHand 给的模板 SHA-256；不一致就停止。

1. 在受管 Sites 中创建仅本人可访问的私有 Site。保持 owner-private audience；不要为了让 Mac 能访问而改公开范围。部署前用真实平台 owner 身份证据设置 `OWNER_SUBJECT_PIN`，首次真实 MCP 请求会按平台同 Site 身份合同自动核对请求主体、已有 owner pin 和 owner_registry，并记录本部署来源的首次匹配事实；无需手工设置映射已验证标记或调用身份工具。每次请求仍校验当前主体，旧记录不能代替权限。无法证明唯一 owner 时停止。
2. 用受支持的 Sites 流程绑定私有 D1 为 `DB`，按顺序应用 `migrations/0001_b_site.sql`、`migrations/0003_host_app_flow.sql`、`migrations/0004_request_keys.sql`、`migrations/0005_site_enrollment.sql`、`migrations/0006_v412_scoped_relay.sql`、`migrations/0007_mcp_owner_observations.sql`，再在真实 D1 primary 核表和约束（含 rc_scopes/rc_jobs/rc_chunks）。保留原迁移编号，不重编号；此归档不含发行存储或发行扩展，也不在 Worker 请求中迁移数据库。平台若不能按这些 SQL 建库，停止并报告缺口。
3. 在真实 Site 部署设置非秘密 `SITE_ID`、规范的 `SITE_ORIGIN`、`SITE_SOURCE_REVISION`、`SITES_MANAGED_PRIVATE=true`、`PAIRING_HASH`（从这台 Mac 刚复制的 64 位值）、`TEMPLATE_VERSION=1052-site-b-v3`、`MANIFEST_SHA256`（对本归档内 `template-manifest.json` 文件原始字节求 SHA-256，或取打包工具输出的 `manifest_sha256`；该文件不内嵌自己的 SHA）。Site 的签名私钥、设备发放密钥、结果加密密钥按正式受管 secret 流程生成并设置为 `SITE_SIGNING_PRIVATE_PKCS8`、`DEVICE_ISSUE_SECRET`、`SITE_RESULT_KEY`；对应 `SITE_SIGNING_PUBLIC_KEY` 必须由同一签名密钥导出。不得把真实秘密写在源码、命令参数、日志或此文件。`PAIRING_HASH` 只用于这台 Mac 本次配对，一次成功后不可复用。
4. 部署后，从 Sites 正式 `get_site` 响应读取本 Site 的 `site_id`、`site_origin` 和 `siwc_bypass_bearer_token`。服务 bearer 仅送往该 Site，作为 `OAI-Sites-Authorization: Bearer` 由 Sites dispatch 校验；它不是 owner 身份。不要在 Worker 里另设或验证同名凭据。若 `get_site` 未返回所需三项，停止；不要猜地址或凭据。
5. 在原 Site 对话中，将真实结果组成且仅组成一行 JSON：`{"format":"chathand-site-v2","site_origin":"<真实 site_origin>","site_id":"<真实 site_id>","service_credential":"<真实 siwc_bypass_bearer_token>"}`。如有受控本机标准输入通道，可直接交给随包 `scripts/setup.mjs site`；否则告诉用户 这段对话会留存凭据，再请用户 点代码块的「复制」并回到 ChatHand F11，未自动接收时由用户 在该窗口按 ⌘V。不能把复制、Site 创建或本机收取当作配对完成。
6. ChatHand 收到一行资料后自动使用原设备身份完成配对、完整工具与任务卡/图片资源登记、签名 WebSocket 连接和后续轮换，不要求用户提供 owner/binding/session/request ID 或另设运行密钥。只有 ChatHand 返回已配对并通过签名健康检查后，才在新的 ChatGPT 对话以同一个 nonce 调用 `connection_check`、`setup_write_probe`；后者挂载现有任务组件并自动交回私有应用回执，无需额外点击。接着用 Mac 原有工具做 read_write 验收，工具一次调用直接回结果，不使用旧两步领取/取结果工具。账号权限、插件连接、系统权限和任何正式发布动作由本人或平台处理。

## 更新已有 Site

若 ChatHand 报模板版本不符，在建这个 Site 的原项目、原 `project_id` 中，按 Sites 官方更新工具把本归档的新 `server/index.js` 和 `.openai/hosting.json` 更新到**同一个 Site**；先对原 D1 应用本归档新增的迁移，再设置新 `TEMPLATE_VERSION` 和按新 `template-manifest.json` 文件字节计算的 `MANIFEST_SHA256`。更新后用官方 `get_site` 核对原 `site_id`、`site_origin`、owner-private audience 和 owner 映射仍一致，再让 ChatHand 验签健康状态恢复。保留原 Site 的配对记录、签名密钥、设备密钥、D1 数据和 `OWNER_SUBJECT_PIN`；不要重新生成设备密钥、`PAIRING_HASH`、新 `project_id` 或调用创建新 Site 的工具。临时版本不符时不要改 origin、公开范围或重建 Site 来绕过失败。若官方更新工具不支持在原项目更新同一个 Site，停止并报告此缺口。

同一个 Site 的服务 bearer 更新时，仍从该 Site 的真实 `get_site` 取得新值，以同一四字段格式交给 ChatHand；无需生成新设备身份。若实际 Site 的 origin 或 owner 变化，这不是单纯换凭据，先停止并重新核对部署身份。不要输出或记录新的 bearer。

真实平台的 owner pin 取得、`get_site` 凭据可用性、dispatch、D1、浏览器、原生剪贴板和目标 ChatGPT 验收，都不能由离线源码测试代替。

连接刷新和设备重连由应用自动进行，不要求用户重复粘贴、轮询取结果或单独确认 WebSocket。真实离线和 unknown 原样报告；unknown 不自动重发。首次与手动配置仍只需上述一次复制回传，平台原有连接/允许工具由本人确认。
