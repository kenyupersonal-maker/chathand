# ChatHand ChatGPT Site 模板步骤

此归档包含私有 Site B 通道源码、完整的 `drizzle/` 历史和宿主页面，不含真实 Site 身份、密钥、服务凭据或部署记录。先核对 ChatHand 给的 ZIP SHA-256，不一致就停止。用户发送建站提示词即授权本流程内的源码推送和私有部署；保持原 owner-private audience，不改公开范围。真实平台结果不能由离线测试代替。

## 开始或中断后继续

先核当前状态，再补缺项。已有 Site、原 Work 或检查点都继续复用；不因缺表、缺环境变量或新版归档新建 Site。**准备源码以前，`.openai/hosting.json` 必须已有本 Site 的 `project_id`。** 不将模板的无 ID 配置覆盖原 hosting；保留其他绑定和能力字段。

1. 已部署成功的旧源码需要改成新源码时，直接转“更新已有 Site”，不运行旧操作的 open/init。首次部署或相同源码仍在中断恢复时，只在同一个解压项目运行 `node scripts/site-deploy-checkpoint.mjs open`。检查点/hosting ID 冲突就停止。若原 Work 已有 create_site 成功回执，立即 `node scripts/site-deploy-checkpoint.mjs record-project --project-id <原样id>`，它先写 hosting 再写检查点。只有确认从未创建、也没有结果未知的创建尝试，才调用一次 `create_site` 并立即 record-project；创建回执不明时先正式查询，不能按 slug 猜或再创建。已有 ID 用 `get_site` 核原项目和私有范围。
2. 每次准备源码前，都为该 ID 重新调用 `create_source_repository_write_credential`。只核四个字段存在：`auth_mode=http_extra_header`、`token`、`remote_url`、`branch`；不显示值、不存盘。凭据仅在内存中经官方 source helper 的隐藏 stdin 传递，不放命令参数或检查点。hosting ID 和这份凭据项目必须一致。
3. 用 `get_environment_variables` **只看变量名是否存在**，不读取或复述既有 secret 值；用 `read_database_overview` 看现有表和迁移状态。保留现有 `OWNER_SUBJECT_PIN`、四把密钥、配对记录、签名身份和设备身份。PIN 已存在就保持入口关闭，跳过认主人；不能为修缺表重新打开入口。核是否已有设备配对只取得存在性，不复制业务行。迁移状态不明或与本归档的历史冲突时停止，不试着重复跑 SQL。
4. 合并源码时保留 hosting、旧检查点和原身份。若旧部署已 succeeded 但本次需新源码，转到“更新已有 Site”；不将新 commit/archive 塞进旧 init。尚在进行的同一源码操作使用下方检查点恢复。首次准备用官方 source helper 推精确源提交并打同份部署 archive；凭据只经隐藏 stdin。source helper 的 commands 使用 `[["node","scripts/build-site.mjs"]]`，它从 server 和 hosting 生成官方打包要求的 dist；不需安装包。取得实际完整 commit 后设 `SITE_SOURCE_REVISION`。运行 `node scripts/site-deploy-checkpoint.mjs init --commit <完整SHA> --archive-sha256 <64位sha256>`，记录非秘密编号。检查点必须在 `.git/info/exclude` 排除，不提交也不装入发布包；不并行写。源码/归档摘要冲突保留原证据并停止。

### 只补缺失的环境和四把密钥

第一次部署前把已知值一次设齐：`SITES_MANAGED_PRIVATE=true`、真实 `SITE_ID`、实际推送的 `SITE_SOURCE_REVISION`、`TEMPLATE_VERSION=1070-site-b-v7`、本归档 `template-manifest.json` 原始字节的 SHA-256 作为 `MANIFEST_SHA256`。未配对 Site 使用这台 Mac 建站提示词已有的 `PAIRING_HASH`；缺失时从原 Work 的本次建站提示词取得，不能自行造值或复用已消费的哈希。已配对 Site 不更换 `PAIRING_HASH`。get_site 已有且可证实的真实 `site_origin` 可提前设为 `SITE_ORIGIN`，不能猜地址。

四项名字为 `SITE_SIGNING_PRIVATE_PKCS8`、`SITE_SIGNING_PUBLIC_KEY`、`DEVICE_ISSUE_SECRET`、`SITE_RESULT_KEY`。只在四项全缺且确认从未配对时，**运行一次** `node scripts/site-secrets.mjs`（无参数）。它仅用 Node 自带 crypto，向 stdout 打一行 JSON；把那一行原样用于**一次** `update_environment_variables` 的四项值，三把私密的设为 secret，公钥可以不设为 secret。值仅在本人私有 Work 的这一次工具记录内出现；不写文件、源码、日志，不在回复里重复，不在其他终端运行。中断后先 `get_environment_variables` 只核名字：四项已有就不再生成；部分已有而部分缺失不能重生成整组，先恢复原私有对话中的同一行或报告缺口。Site 已经配对过 Mac 的，永远不重新生成。密钥输出后写入结果 unknown 时也先查名字，不重复运行脚本。

### 部署、建表和认主人

平台在部署时按 `drizzle/meta/_journal.json` 自动应用尚未执行的迁移，不用手动跑 SQL，不在 Worker 请求中建表。归档不含 `migrations/`；原 SQL 仅留在开发源码作为输入证据。历史 0000–0003（含 release_storage）原样保留；新 0004/0005/0006 对应原输入 0005/0006/0007，快照和 journal 都随包。

- **PIN 已存在：** 保持 `OWNER_BOOTSTRAP_ENABLED=false`，补缺的环境、原身份对应密钥和新源码后部署一次建全表。
- **PIN 缺失且已知真实 origin：** 首次部署前设 `OWNER_BOOTSTRAP_ENABLED=true` 和 `SITE_ORIGIN`，部署后进入取身份，再钉 PIN/关入口部署一次，共两次。必须有 get_site 的真实 origin 证据。
- **全新 Site、origin 尚无：** 第一次部署前设 `OWNER_BOOTSTRAP_ENABLED=true` 和所有上述已知环境及四把密钥，部署成功后 `get_site` 取真实 `site_origin`，设 `SITE_ORIGIN`，**同一个已保存版本再部署一次**。Mac mini 已实测只改环境不重新部署会报 `B_BOOTSTRAP_CONTEXT_UNVERIFIED`，不能直接取身份。然后钉 PIN/关入口再部署，共三次。

第一次部署成功后立即 `read_database_overview`，确认 `owner_registry`、`b_v2_intents`、`rc_scopes`、`rc_jobs`、`rc_chunks`、`mcp_owner_observations` 等表存在（完整历史共 20 张业务表，含 3 张 release 表）；缺表就停下说明，不把部署 succeeded 当建表通过。平台概要不能证明约束已验；不能连生产库手工补 SQL 来绕过迁移状态。

需要认主人时，给用户真实 `SITE_ORIGIN` 加 `/bootstrap/identity?nonce=<本次随机nonce>` 的链接（nonce 为 16–128 位 base64url 字符）。告诉他：“打开链接；需要登录时点 Continue with ChatGPT，选择自己的账号；页面显示身份资料已准备后，点「复制身份资料」，回到创建这个 Site 的原 Work 对话粘贴发送；如果页面显示错误码，把错误码交给原 Work 对话排查，不把它当作已取得身份。”核该行的 site_id、origin、source_revision、nonce 和时效均对应本次请求，再把 `owner_subject` 设为 secret `OWNER_SUBJECT_PIN`，设 `OWNER_BOOTSTRAP_ENABLED=false`，同一保存版本再次部署。身份那一行不落盘、不在回复里重复。已有 PIN 不走此步骤；身份不匹配或不能证明唯一 owner 就停止。首次真实 MCP 请求仍按平台同 Site 身份核当前主体、PIN 和 owner_registry，不靠手工映射标志代替权限。

### 同一部署的检查点恢复

5. 每次重入运行 `node scripts/site-deploy-checkpoint.mjs plan`，照返回阶段继续。版本未知（`reconcile_versions`）时先用 `list_site_versions(project_id)` 按 cursor 翻完所需页，核对同 project_id、精确 `source.commit_sha` 与归档证据。不要把 content_hash 的未知格式猜成 archive SHA-256；只有平台明确摘要含义且与同份归档吻合才使用。唯一且证据足够的版本，用 `record-version --version-id <真实版本id>` 记录；若有 deployment_id，一并用下一步记录。多项歧义、摘要不符、保存回执曾丢失而查询证据不足时报告 unknown，不再 save。只有确认本次从未 save、且完整查询无现有匹配版本，才可上传一次并调用 `save_version_and_deploy_private`；请求发出前后中断但未能确认结果时，重入必须先查询，不能依据“本地没有版本id”重传。
6. 组合工具成功或报错都按其正式结果核对。**错误带 `saved_version_id` 时立即记录此 ID（`record-version --version-id <saved_version_id>`），不得再次上传或 save。**成功响应的 version_id 同样立即记录；已有版本只用 `deploy_private_site_version(project_id,version_id)`。在调用之前若既往操作结果 unknown，先查询该版本是否已带 deployment_id；若有就进入下一步，避免重复发布。裸 409 不证明保存/部署成功，也不是重新 create/save 的授权；先查当前项目、版本和回执，不足就保留 unknown。
7. 一旦取得 deployment.id，立即运行 `record-deployment --version-id <真实version_id> --deployment-id <真实deployment.id>`。已有部署（`action=get_deployment_status`）优先调用 `get_deployment_status(project_id,deployment_id)`，不重复发布、不再 save。返回状态只通过 `record-status --deployment-id <同一id> --status <pending|building|publishing|succeeded|failed>` 记录；非终态继续按平台要求查状态。已知 failed 才可用同 saved version 再部署，并记录新 deployment ID；unknown 不等于 failed。只有 succeeded / `action=complete` 才进入部署后 get_site 与四字段配对步骤。

下文命令如未写完整前缀，均指 `node scripts/site-deploy-checkpoint.mjs <命令>`；尖括号必须替换为正式平台返回的原样非敏感 ID。命令参数只允许上述白名单，不传 secret，不给脚本传工具原始响应。该脚本使用临时文件、fsync、rename 原子写 JSON；不允许多个写入者同时运行。平台工具调用由宿主执行，脚本无法证明其结果真实性。这是阶段级恢复，平台没有提供字节偏移接口时不宣称字节级续传。


## 更新已有 Site

本段后续更新保持原路径，不调用检查点 open/init，不覆盖或删除旧检查点。旧操作未终态时先核原部署；多次更新的独立检查点不在此脚本范围。保留原项目、原 `project_id`，用同一个 Site 的官方更新工具；新归档先解到临时目录，再合并新 server、drizzle、scripts 与文档，保留 hosting 的 ID 和其他配置。不覆盖已应用的 SQL、snapshot 或 journal 条目。

更新前 get_site 核原 owner-private audience，get_environment_variables 只核名字，read_database_overview 核表及可用的迁移证据；每次准备源码仍重新取该项目的四字段源码凭据并经隐藏 stdin 使用。用 `[["node","scripts/build-site.mjs"]]` 准备同份部署包，推新源码、记录实际 commit，设置新 `SITE_SOURCE_REVISION`、`TEMPLATE_VERSION` 和 `MANIFEST_SHA256`，按上面的缺项规则补齐环境后私有部署；平台只应用待执行的 drizzle 条目。旧四条历史原样存在的 Site 从新 0004 继续，空库从 0000 开始。源码/旧部署记录仅能说明历史兼容，无法证明真实 D1 的已应用账本；未知就先报告，不篡改 journal 或重复 ALTER TABLE。更新完成再 read_database_overview 核表。

保留原 Site 的配对记录、四把密钥、D1 数据和 `OWNER_SUBJECT_PIN`；已配对时不要重新生成密钥、`PAIRING_HASH` 或设备身份。PIN 已存在始终关闭 bootstrap。若原项目 PIN 已钉但表空、从未配对且四把密钥全缺，可按上节补缺后一次部署。若官方工具不支持同项目更新，停止报告缺口。origin 或 owner 变化时先停止核对，不能改公开范围或另建 Site 绕过版本不符。

## 交给 ChatHand 并验收

完成所有必要部署后，再用正式 `get_site` 取本 Site 的 `site_id`、`site_origin`、`siwc_bypass_bearer_token`。必须三项齐全，不猜地址和凭据。组成且仅组成一行 JSON：`{"format":"chathand-site-v2","site_origin":"<真实 site_origin>","site_id":"<真实 site_id>","service_credential":"<真实 siwc_bypass_bearer_token>"}`。服务 bearer 仅给该 Site，由 dispatch 校验，不是 owner 身份，不在 Worker 另设同名凭据。除这一行必要交付外不重复展示 bearer。

有受控本机 stdin 时交随包 `scripts/setup.mjs site`；否则说明凭据留在本人私有 Work，用户点代码块“复制”，回 ChatHand F11，未自动接收时在窗口按 ⌘V。复制或收取不等于配对完成。ChatHand 自动使用原设备身份完成配对、工具/任务卡/图片登记、签名 WebSocket 和轮换；只有返回已配对并验签健康成功后，才在新 ChatGPT 对话用同一 nonce 调 `connection_check`、`setup_write_probe`，再用 Mac 原有工具做 read_write 验收。工具一次调用直接回结果。真实平台/浏览器/剪贴板/目标对话验收仍需实测。unknown 原样报告，不自动重发。

## 改连这台 Mac

每次逐字展示 setup 返回的当前中英文问题和选项，不能沿用旧回答。低于当前模板时先原地更新同一 Site（ID、origin、DB、owner PIN、签名身份不变），更新后重新配对、重新问。结果 unknown 先查询同一版本/部署；只有当前更新的确证终局失败才记录失败并重新提供两个选项。

本人选择改连后，在已登录浏览器打开 setup 返回的 authorization_url（同一 Site 的 /owner/rebind）。页面只使用 fragment 中的本次非秘密上下文并立即清除 fragment；不要手工改参数。点击授权，再点 Copy；授权仅驻留页面内存，不发到聊天。立即在本机执行 setup site-replace --grant-from-clipboard。授权过期、App 重启或问题改变时重新配对、重新提问，不复用授权。B_BOOTSTRAP_DISABLED 指初始身份取得已关闭，不能为改连重开 bootstrap。

插件描述不带版本号；更新已有插件时移除旧描述中的版本号。
