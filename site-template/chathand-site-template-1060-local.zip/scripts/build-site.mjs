#!/usr/bin/env node
/** Build the retained source template for the official Sites package helper. */
import fs from 'node:fs';
import path from 'node:path';
if(process.argv.length!==2)throw Error('SITE_BUILD_NO_ARGUMENTS');
for(const name of ['server/index.js','.openai/hosting.json']){
 const source=path.resolve(name),stat=fs.lstatSync(source);
 if(!stat.isFile()||stat.isSymbolicLink())throw Error('SITE_BUILD_SOURCE_UNSAFE');
 const target=path.resolve('dist',name);fs.mkdirSync(path.dirname(target),{recursive:true});
 fs.copyFileSync(source,target);
}
