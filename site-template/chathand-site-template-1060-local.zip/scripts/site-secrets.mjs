#!/usr/bin/env node
/** Run once in the private Site Work. No arguments, files or dependencies. */
import {generateKeyPairSync,randomBytes} from 'node:crypto';
if(process.argv.length!==2){process.stderr.write('SITE_SECRETS_NO_ARGUMENTS\n');process.exit(64);}
const {privateKey,publicKey}=generateKeyPairSync('ed25519');
const publicJwk=publicKey.export({format:'jwk'});
const raw=Buffer.from(publicJwk.x,'base64url');
if(raw.length!==32)throw Error('SITE_SECRETS_PUBLIC_KEY_INVALID');
process.stdout.write(JSON.stringify({
 SITE_SIGNING_PRIVATE_PKCS8:privateKey.export({format:'der',type:'pkcs8'}).toString('base64url'),
 SITE_SIGNING_PUBLIC_KEY:raw.toString('base64url'),
 DEVICE_ISSUE_SECRET:randomBytes(32).toString('base64url'),
 SITE_RESULT_KEY:randomBytes(32).toString('base64url')
})+'\n');
