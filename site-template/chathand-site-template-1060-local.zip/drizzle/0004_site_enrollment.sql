-- Source-only additive Site B v2 enrollment ledger. Apply only during a
-- separately authorized private Site migration; this file never runs at boot.
-- pairing_hash is one-use per deployed Site. A retained proof lets the exact
-- same complete request recover its signed receipt after a lost response.
CREATE TABLE IF NOT EXISTS b_v2_intents (
  pairing_hash TEXT PRIMARY KEY CHECK(length(pairing_hash)=64),
  intent_id TEXT NOT NULL,
  pairing_id TEXT NOT NULL UNIQUE REFERENCES pairing_grants(pairing_id),
  proof_digest TEXT NOT NULL CHECK(length(proof_digest)=64),
  consumed_at INTEGER NOT NULL,
  retention_until INTEGER NOT NULL CHECK(retention_until>consumed_at)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_v2_intent_retention ON b_v2_intents(retention_until);
--> statement-breakpoint
-- D1 batch is transactional, but a zero-row UPDATE does not throw. Reject a
-- consumed/expired owner grant before the first write so an owner-grant race
-- cannot commit an intent, binding and receipt with update count 0.
CREATE TRIGGER IF NOT EXISTS b_v2_intent_requires_fresh_grant
BEFORE INSERT ON b_v2_intents
BEGIN
  SELECT RAISE(ABORT,'B_V2_GRANT_NOT_FRESH')
  WHERE NOT EXISTS (
    SELECT 1 FROM pairing_grants g JOIN owner_grants o ON o.grant_id=g.grant_id
    WHERE g.pairing_id=NEW.pairing_id
      AND json_extract(g.claim_json,'$.protocol_version')='2'
      AND json_extract(g.claim_json,'$.pairing_hash')=NEW.pairing_hash
      AND g.consumed_at IS NULL AND g.consume_claim IS NULL
      AND o.used_at IS NULL
      AND g.expires_at>=unixepoch() AND o.expires_at>=unixepoch()
  );
END;
--> statement-breakpoint
-- A race that makes either UPDATE touch zero rows must abort the entire D1
-- batch. Checking meta.changes after the batch is too late to prevent an
-- intent/binding/receipt from being committed.
CREATE TRIGGER IF NOT EXISTS b_v2_binding_requires_consumed_grant
BEFORE INSERT ON device_bindings
WHEN (SELECT json_extract(claim_json,'$.protocol_version') FROM pairing_grants WHERE grant_id=NEW.grant_id)='2'
BEGIN
  SELECT RAISE(ABORT,'B_V2_GRANT_NOT_CONSUMED')
  WHERE NOT EXISTS (
    SELECT 1 FROM pairing_grants g JOIN owner_grants o ON o.grant_id=g.grant_id
    JOIN b_v2_intents i ON i.pairing_id=g.pairing_id
    WHERE g.grant_id=NEW.grant_id AND g.consume_claim=NEW.create_claim
      AND g.consumed_at IS NOT NULL AND o.used_at IS NOT NULL
      AND i.pairing_hash=json_extract(g.claim_json,'$.pairing_hash')
  );
END;
