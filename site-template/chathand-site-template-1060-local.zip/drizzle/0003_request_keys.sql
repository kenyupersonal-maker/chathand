-- ONE1052 B request-id durable idempotency ledger. Source migration 0004.
-- Each successful request-key INSERT creates precisely one queue row in the
-- SAME SQLite statement via trigger. Duplicates never invoke this trigger.
CREATE TABLE IF NOT EXISTS b_request_keys (
  site_id TEXT NOT NULL,
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  binding_id TEXT NOT NULL REFERENCES device_bindings(binding_id),
  request_id TEXT NOT NULL CHECK(length(request_id) >= 12 AND length(request_id) <= 96),
  generation INTEGER NOT NULL CHECK(generation > 0),
  op_id TEXT NOT NULL UNIQUE,
  tool_name TEXT NOT NULL,
  arguments TEXT NOT NULL,
  request_digest TEXT NOT NULL CHECK(length(request_digest) = 64),
  semantic_digest TEXT NOT NULL CHECK(length(semantic_digest) = 64),
  session_tag TEXT CHECK(session_tag IS NULL OR length(session_tag) = 64),
  created_at INTEGER NOT NULL,
  start_before INTEGER NOT NULL CHECK(start_before >= created_at),
  PRIMARY KEY(site_id,owner_subject,installation_id,binding_id,request_id)
);
--> statement-breakpoint
CREATE TRIGGER b_request_key_queues_once
AFTER INSERT ON b_request_keys
BEGIN
  INSERT INTO b_operations(
    site_id,owner_subject,installation_id,binding_id,generation,
    op_id,tool_name,arguments,request_digest,status,created_at,start_before
  ) VALUES (
    NEW.site_id,NEW.owner_subject,NEW.installation_id,NEW.binding_id,NEW.generation,
    NEW.op_id,NEW.tool_name,NEW.arguments,NEW.request_digest,'queued',
    NEW.created_at,NEW.start_before
  );
END;
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_request_key_operation
  ON b_request_keys(owner_subject,installation_id,op_id);
