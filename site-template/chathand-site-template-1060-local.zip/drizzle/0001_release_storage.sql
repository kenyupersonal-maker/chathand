-- ONE1052 release artifact storage, owner-private Site only.
-- Additive schema migration, applied by root before enabling release upload.
-- No release READY row is created by migration.
CREATE TABLE IF NOT EXISTS release_uploads (
 attempt_id TEXT PRIMARY KEY,
 owner_subject TEXT NOT NULL REFERENCES owner_registry(owner_subject),
 site_id TEXT NOT NULL,
 build_number INTEGER NOT NULL CHECK(build_number>0),
 version TEXT NOT NULL,
 object_key TEXT NOT NULL,
 expected_sha256 TEXT NOT NULL CHECK(length(expected_sha256)=64),
 expected_size INTEGER NOT NULL CHECK(expected_size>0),
 mode TEXT NOT NULL CHECK(mode IN ('single','multipart')),
 part_size INTEGER NOT NULL,
 multipart_upload_id TEXT,
 state TEXT NOT NULL CHECK(state IN ('pending','uploaded','complete','aborted')),
 created_at INTEGER NOT NULL,
 completed_at INTEGER
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_release_attempt_owner ON release_uploads(owner_subject,build_number,created_at);
--> statement-breakpoint
-- Prevent two still-writable attempts from racing to replace one immutable key.
-- Root must apply this migration before any release upload endpoint is enabled.
CREATE UNIQUE INDEX IF NOT EXISTS b_release_one_active_attempt
 ON release_uploads(build_number) WHERE state IN ('pending','uploaded');
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS release_parts (
 attempt_id TEXT NOT NULL REFERENCES release_uploads(attempt_id),
 part_number INTEGER NOT NULL CHECK(part_number>=1 AND part_number<=10000),
 part_etag TEXT NOT NULL,
 part_size INTEGER NOT NULL CHECK(part_size>0),
 PRIMARY KEY(attempt_id,part_number)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS release_ready (
 build_number INTEGER PRIMARY KEY CHECK(build_number>0),
 version TEXT NOT NULL,
 site_id TEXT NOT NULL,
 owner_subject TEXT NOT NULL REFERENCES owner_registry(owner_subject),
 object_key TEXT NOT NULL UNIQUE,
 sha256 TEXT NOT NULL CHECK(length(sha256)=64),
 size_bytes INTEGER NOT NULL CHECK(size_bytes>0),
 ready_at INTEGER NOT NULL,
 committed_attempt_id TEXT NOT NULL UNIQUE REFERENCES release_uploads(attempt_id)
);
