-- ONE1052 Site B D1 primary migration, isolated owner-private Worker only.
-- Schema-only. Root must apply through supported Sites storage workflow before enabling DB.
-- No runtime CREATE TABLE and no in-process per-request migration.
CREATE TABLE IF NOT EXISTS owner_registry (
  owner_subject TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS owner_grants (
  grant_id TEXT PRIMARY KEY,
  grant_hash TEXT NOT NULL UNIQUE,
  site_id TEXT NOT NULL,
  owner_subject TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  used_at INTEGER,
  FOREIGN KEY(owner_subject) REFERENCES owner_registry(owner_subject)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS pairing_grants (
  grant_id TEXT PRIMARY KEY REFERENCES owner_grants(grant_id),
  site_id TEXT NOT NULL,
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  public_key_id TEXT NOT NULL,
  public_key_raw TEXT NOT NULL,
  pairing_id TEXT NOT NULL UNIQUE,
  claim_digest TEXT NOT NULL,
  claim_json TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  consumed_at INTEGER,
  consume_claim TEXT UNIQUE
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS device_bindings (
  binding_id TEXT PRIMARY KEY,
  grant_id TEXT UNIQUE NOT NULL REFERENCES pairing_grants(grant_id),
  site_id TEXT NOT NULL,
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  public_key_id TEXT NOT NULL,
  device_public_key_raw TEXT NOT NULL,
  generation INTEGER NOT NULL CHECK(generation>0),
  create_claim TEXT UNIQUE NOT NULL,
  device_credential_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL DEFAULT 0,
  revoked_at INTEGER,
  UNIQUE(site_id,owner_subject,installation_id,generation)
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS b_one_active_binding ON device_bindings(site_id,owner_subject,installation_id) WHERE revoked_at IS NULL;
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS pairing_receipts (
  pairing_id TEXT PRIMARY KEY,
  grant_id TEXT NOT NULL UNIQUE REFERENCES pairing_grants(grant_id),
  binding_id TEXT NOT NULL UNIQUE REFERENCES device_bindings(binding_id),
  receipt_digest TEXT NOT NULL,
  create_claim TEXT NOT NULL UNIQUE
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS device_nonces (
  binding_id TEXT NOT NULL REFERENCES device_bindings(binding_id),
  kind TEXT NOT NULL,
  nonce TEXT NOT NULL,
  seen_at INTEGER NOT NULL,
  PRIMARY KEY(binding_id,kind,nonce)
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS b_operations (
  site_id TEXT NOT NULL,
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  binding_id TEXT NOT NULL REFERENCES device_bindings(binding_id),
  generation INTEGER NOT NULL,
  op_id TEXT NOT NULL,
  tool_name TEXT NOT NULL,
  arguments TEXT NOT NULL,
  request_digest TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('queued','leased','completed','expired','revoked')),
  created_at INTEGER NOT NULL,
  start_before INTEGER NOT NULL,
  lease_claim TEXT,
  leased_until INTEGER,
  result_digest TEXT,
  PRIMARY KEY(owner_subject,installation_id,op_id)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_op_binding_status ON b_operations(binding_id,generation,status,created_at);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS b_results (
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  op_id TEXT NOT NULL,
  binding_id TEXT NOT NULL,
  request_digest TEXT NOT NULL,
  result_digest TEXT NOT NULL,
  ack_id TEXT NOT NULL UNIQUE,
  result_box TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(owner_subject,installation_id,op_id),
  FOREIGN KEY(owner_subject,installation_id,op_id) REFERENCES b_operations(owner_subject,installation_id,op_id)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_result_owner ON b_results(owner_subject,installation_id);
