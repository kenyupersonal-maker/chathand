-- Appended V4.1.2 ledger. All times here are milliseconds; legacy tables retain their units.
CREATE TABLE rc_scopes(scope_key TEXT PRIMARY KEY NOT NULL,site_id TEXT NOT NULL,owner_subject TEXT NOT NULL,installation_id TEXT NOT NULL,binding_id TEXT NOT NULL,generation INTEGER NOT NULL,FOREIGN KEY(binding_id) REFERENCES device_bindings(binding_id));
--> statement-breakpoint
CREATE TABLE rc_jobs(scope_key TEXT NOT NULL,id TEXT PRIMARY KEY NOT NULL,dedupe_key TEXT UNIQUE NOT NULL,caller_hash TEXT NOT NULL,rpc_id_json TEXT NOT NULL,session_hash TEXT NOT NULL,request_hash TEXT NOT NULL,method TEXT NOT NULL,request_bytes INTEGER NOT NULL,request_chunks INTEGER NOT NULL,response_hash TEXT,response_bytes INTEGER,response_chunks INTEGER,created_at INTEGER NOT NULL,expires_at INTEGER NOT NULL,tombstone_until INTEGER NOT NULL,completed_at INTEGER,status TEXT NOT NULL,claim_id TEXT,cancel_requested INTEGER NOT NULL DEFAULT 0,http_wait_until INTEGER,claimed_at INTEGER,consumed_at INTEGER,waiters INTEGER NOT NULL DEFAULT 0,FOREIGN KEY(scope_key) REFERENCES rc_scopes(scope_key),UNIQUE(scope_key,id));
--> statement-breakpoint
CREATE TABLE rc_chunks(scope_key TEXT NOT NULL,job_id TEXT NOT NULL,direction TEXT NOT NULL,sequence INTEGER NOT NULL,chunk_hash TEXT NOT NULL,data_b64 TEXT NOT NULL,PRIMARY KEY(job_id,direction,sequence),FOREIGN KEY(scope_key,job_id) REFERENCES rc_jobs(scope_key,id) ON DELETE CASCADE);
--> statement-breakpoint
CREATE TABLE rc_devices(scope_key TEXT NOT NULL,id TEXT PRIMARY KEY NOT NULL,last_seen INTEGER NOT NULL,generation TEXT NOT NULL,warm_until INTEGER NOT NULL DEFAULT 0,FOREIGN KEY(scope_key) REFERENCES rc_scopes(scope_key));
--> statement-breakpoint
CREATE TABLE rc_runtime(scope_key TEXT NOT NULL,id TEXT PRIMARY KEY NOT NULL,manifest_json TEXT NOT NULL,settings_json TEXT NOT NULL,revision TEXT NOT NULL,updated_at INTEGER NOT NULL,FOREIGN KEY(scope_key) REFERENCES rc_scopes(scope_key));
--> statement-breakpoint
CREATE INDEX rc_scope_queue ON rc_jobs(scope_key,status,created_at);
--> statement-breakpoint
CREATE INDEX rc_scope_expiry ON rc_jobs(scope_key,expires_at,tombstone_until);
--> statement-breakpoint
-- Retired queued operations are never imported into the new ledger. Existing uncertain leases stay unknown.
UPDATE b_operations SET status='expired' WHERE status='queued';
--> statement-breakpoint
ALTER TABLE b_operations ADD COLUMN retired_transport_state TEXT;
--> statement-breakpoint
UPDATE b_operations SET retired_transport_state='unknown' WHERE status='leased';
