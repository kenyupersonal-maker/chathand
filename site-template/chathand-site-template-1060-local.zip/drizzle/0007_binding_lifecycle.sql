-- Explicit binding protocol 3; no runtime DDL and no destructive history migration.
ALTER TABLE device_bindings ADD COLUMN device_name TEXT;
--> statement-breakpoint
ALTER TABLE device_bindings ADD COLUMN last_used INTEGER;
--> statement-breakpoint
ALTER TABLE device_bindings ADD COLUMN replaced_by_binding_id TEXT;
--> statement-breakpoint
ALTER TABLE device_bindings ADD COLUMN replaced_at INTEGER;
--> statement-breakpoint
CREATE TABLE b_rebind_grants (
 grant_hash TEXT PRIMARY KEY,site_id TEXT NOT NULL,owner_subject TEXT NOT NULL,
 installation_id TEXT NOT NULL,pairing_hash TEXT NOT NULL,
 expected_bindings TEXT NOT NULL,expires_at INTEGER NOT NULL,used_at INTEGER,consume_claim TEXT UNIQUE
);
--> statement-breakpoint
CREATE TABLE b_v3_intents (
 pairing_id TEXT PRIMARY KEY REFERENCES pairing_grants(pairing_id),
 intent_id TEXT NOT NULL,proof_digest TEXT NOT NULL,
 consumed_at INTEGER NOT NULL,retention_until INTEGER NOT NULL
);
--> statement-breakpoint
-- CAS before any mutation: never select a winner from pre-existing ambiguity.
CREATE TRIGGER b_v3_intent_requires_current_binding BEFORE INSERT ON b_v3_intents BEGIN
 SELECT RAISE(ABORT,'B_BINDING_CHANGED') WHERE NOT EXISTS (
  SELECT 1 FROM pairing_grants g JOIN owner_grants o ON o.grant_id=g.grant_id
  WHERE g.pairing_id=NEW.pairing_id AND g.consumed_at IS NULL AND o.used_at IS NULL
   AND g.expires_at>=unixepoch() AND o.expires_at>=unixepoch()
   AND json_extract(g.claim_json,'$.protocol_version')='3'
   AND (SELECT COUNT(*) FROM device_bindings b WHERE b.site_id=g.site_id AND b.owner_subject=g.owner_subject AND b.revoked_at IS NULL)=json_array_length(json_extract(g.claim_json,'$.expected_bindings'))
   AND NOT EXISTS (
    SELECT 1 FROM json_each(json_extract(g.claim_json,'$.expected_bindings')) e
    WHERE NOT EXISTS (SELECT 1 FROM device_bindings b WHERE b.site_id=g.site_id AND b.owner_subject=g.owner_subject AND b.revoked_at IS NULL AND b.binding_id=json_extract(e.value,'$.binding_id') AND b.generation=json_extract(e.value,'$.generation'))
   )
 );
END;
--> statement-breakpoint
CREATE TRIGGER b_v3_binding_requires_consumed_grant BEFORE INSERT ON device_bindings
WHEN (SELECT json_extract(claim_json,'$.protocol_version') FROM pairing_grants WHERE grant_id=NEW.grant_id)='3'
BEGIN
 SELECT RAISE(ABORT,'B_V3_GRANT_NOT_CONSUMED') WHERE NOT EXISTS (
  SELECT 1 FROM pairing_grants g JOIN owner_grants o ON o.grant_id=g.grant_id JOIN b_v3_intents i ON i.pairing_id=g.pairing_id
  WHERE g.grant_id=NEW.grant_id AND g.consume_claim=NEW.create_claim AND g.consumed_at IS NOT NULL AND o.used_at IS NOT NULL
 );
END;
--> statement-breakpoint
-- A trigger works on legacy ambiguous databases too; existing rows remain history
-- until owner-authorized CAS replaces them. No new second active row can appear.
CREATE TRIGGER b_one_site_active_before_insert BEFORE INSERT ON device_bindings
WHEN NEW.revoked_at IS NULL BEGIN
 SELECT RAISE(ABORT,'B_SITE_ALREADY_BOUND') WHERE EXISTS (
  SELECT 1 FROM device_bindings WHERE site_id=NEW.site_id AND owner_subject=NEW.owner_subject AND revoked_at IS NULL
 );
END;
--> statement-breakpoint

-- Reject stale generation calculations even if the active set returns to empty.
CREATE TRIGGER b_generation_monotonic_before_insert BEFORE INSERT ON device_bindings BEGIN
 SELECT RAISE(ABORT,'B_BINDING_CHANGED') WHERE NEW.generation <= COALESCE((
  SELECT MAX(generation) FROM device_bindings WHERE site_id=NEW.site_id AND owner_subject=NEW.owner_subject
 ),0);
END;
