-- ONE1052 B host app-flow capability sidecar (private D1, no runtime DDL).
-- Drizzle custom migration generated through the locked drizzle-kit workflow.
-- The original b_results.result_box contains only ordinary tool results.
CREATE TABLE IF NOT EXISTS b_host_flow_caps (
  owner_subject TEXT NOT NULL,
  installation_id TEXT NOT NULL,
  source_op_id TEXT NOT NULL,
  site_id TEXT NOT NULL,
  binding_id TEXT NOT NULL REFERENCES device_bindings(binding_id),
  generation INTEGER NOT NULL CHECK(generation > 0),
  cap_hash TEXT NOT NULL UNIQUE CHECK(length(cap_hash) = 64),
  cap_box TEXT,
  meta_digest TEXT NOT NULL CHECK(length(meta_digest) = 64),
  batch_id TEXT NOT NULL,
  session_tag TEXT NOT NULL CHECK(length(session_tag) = 64),
  nonce_digest TEXT NOT NULL CHECK(length(nonce_digest) = 64),
  read_op_id TEXT NOT NULL,
  read_result_digest TEXT NOT NULL CHECK(length(read_result_digest) = 64),
  write_result_digest TEXT NOT NULL CHECK(length(write_result_digest) = 64),
  selection_revision INTEGER NOT NULL CHECK(selection_revision >= 0),
  reconnect_epoch INTEGER NOT NULL CHECK(reconnect_epoch >= 0),
  transport_epoch INTEGER NOT NULL CHECK(transport_epoch >= 0),
  controller_epoch INTEGER NOT NULL CHECK(controller_epoch >= 0),
  issued_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK(expires_at > issued_at),
  claim_state TEXT NOT NULL DEFAULT 'pending'
    CHECK(claim_state IN ('pending','claimed','expired')),
  claim_id TEXT UNIQUE,
  claim_op_id TEXT UNIQUE,
  claimed_at INTEGER,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(owner_subject,installation_id,source_op_id),
  UNIQUE(owner_subject,installation_id,batch_id),
  FOREIGN KEY(owner_subject,installation_id,source_op_id)
    REFERENCES b_results(owner_subject,installation_id,op_id)
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_host_flow_owner_active
 ON b_host_flow_caps(owner_subject,site_id,binding_id,generation,session_tag,claim_state,expires_at);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS b_host_flow_expiry
 ON b_host_flow_caps(claim_state,expires_at);
